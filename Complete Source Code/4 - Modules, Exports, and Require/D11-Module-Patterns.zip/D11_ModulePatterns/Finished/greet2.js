module.exports.greet = function() {
	console.log('Hello world!');
};