exports = function() {
	console.log('Hello');
}

console.log(exports);
console.log(module.exports);