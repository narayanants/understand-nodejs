var greet = require('./greet');
var greet2 = require('./greet2');
greet2.greet();