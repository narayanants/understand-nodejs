var greet = require('./greet');
greet();